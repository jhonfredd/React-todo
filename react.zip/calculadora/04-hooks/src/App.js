import Memorize from './components/memos/Memorize'
// import Custom from './components/memos/Custom'
// import Ref from './components/Ref'
// import LayoutEffect from './components/LayoutEffect'

const App = () => {
  return (
    <div className='container text-center'>
      {/* <LayoutEffect/> */}
      {/* <Custom/> */}
      {/* <Ref/> */}
      <Memorize/>
    </div>
    // <State/>
  )
}

export default App

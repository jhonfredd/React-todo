import React from 'react'
import { useState,useEffect, useLayoutEffect } from 'react'
const LayoutEffect = () => {
    const [data, setData] = useState([])

    const [length, setLength] = useState(0)

    const newData = [
        {
            name: "jhon",
            emil: "jhoneerrada@mmcom.co"

        },
        {
            name: "jhon",
            emil: "jhoneerrada@mmcom.co"

        },
        {
            name: "jhon",
            emil: "jhoneerrada@mmcom.co"

        },
        {
            name: "jhon",
            emil: "jhoneerrada@mmcom.co"

        },
        {
            name: "jhon",
            emil: "jhoneerrada@mmcom.co"

        }
    ]

    useEffect(() => {
        setTimeout(() => {
            setData(newData);
        }, 5000)
    }, [newData])
    

    useLayoutEffect(() => {
        const tam = data.length;
        setLength(tam)
    }, [])

    return <>
        <h1>Layout Effect</h1>
        <hr />
        <p>Valores : {length} </p>

    </>
}

export default LayoutEffect

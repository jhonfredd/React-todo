import React from 'react'
import { useState } from 'react'
import NumerInput from './NumerInput';

const Calculadora = () => {
    const [suma,setSuma] = useState(0);

  return (
    <div>
      <NumerInput/>
      <br/>      
    </div>
  )
}

export default Calculadora

import React from 'react'
import PropTypes from 'prop-types'

const Resultado = ({operacion, calculo}) => {
  return (
    <div className="mx-1 my-0">
      <br></br>
      <span>{operacion} : {calculo}</span>
    </div>
  )
}

Resultado.propTypes = {
    operacion : PropTypes.string,
    calculo : PropTypes.number,
}

export default Resultado
